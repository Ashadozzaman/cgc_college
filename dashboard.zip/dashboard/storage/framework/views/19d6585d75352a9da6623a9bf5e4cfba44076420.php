
<script src="<?php echo e(asset('/')); ?>assets/admin/libs/jquery/jquery.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/admin/libs/metismenu/metisMenu.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/admin/libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/admin/libs/node-waves/waves.min.js"></script>
<?php echo $__env->yieldContent('custome-js'); ?>;

<script src="<?php echo e(asset('/')); ?>assets/admin/js/app.js"></script><?php /**PATH C:\wamp64\www\dashboard\resources\views/layouts/admin/_script.blade.php ENDPATH**/ ?>