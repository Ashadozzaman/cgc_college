
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-6">
            <script>document.write(new Date().getFullYear())</script> © Qovex.
        </div>
        <div class="col-sm-6">
            <div class="text-sm-right d-none d-sm-block">
                Design & Develop by Themesbrand
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\dashboard\resources\views/layouts/admin/_footer.blade.php ENDPATH**/ ?>