
<script src="{{asset('/')}}assets/admin/libs/jquery/jquery.min.js"></script>
<script src="{{asset('/')}}assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="{{asset('/')}}assets/admin/libs/metismenu/metisMenu.min.js"></script>
<script src="{{asset('/')}}assets/admin/libs/simplebar/simplebar.min.js"></script>
<script src="{{asset('/')}}assets/admin/libs/node-waves/waves.min.js"></script>
@yield('custome-js');

<script src="{{asset('/')}}assets/admin/js/app.js"></script>